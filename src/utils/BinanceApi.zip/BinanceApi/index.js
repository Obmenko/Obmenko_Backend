const pairs = require('./tickerPrice')

pairs().then(
    (response) => {
       console.log(response);
    },
    (error) => {
       console.log(error);
      
    } 
 );

