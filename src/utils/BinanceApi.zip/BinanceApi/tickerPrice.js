
const axios = require('axios')



const stringifyKeyValuePair = ([key, value]) => {
    const valueString = Array.isArray(value) ? `["${value.join('","')}"]` : value
    return `${key}=${encodeURIComponent(valueString)}`
  }

const isEmptyValue = input => {
    
    return (!input && input !== false && input !== 0) ||
      ((typeof input === 'string' || input instanceof String) && /^\s+$/.test(input)) ||
      (input instanceof Object && !Object.keys(input).length) ||
      (Array.isArray(input) && !input.length)
  }

const removeEmptyValue = obj => {
    if (!(obj instanceof Object)) return {}
    Object.keys(obj).forEach(key => isEmptyValue(obj[key]) && delete obj[key])
    return obj
  }

const buildQueryString = params => {
    if (!params) return ''
    return Object.entries(params)
      .map(stringifyKeyValuePair)
      .join('&')
  }

const getRequestInstance = (config) => {
    return axios.create({
      ...config
    })
  }  

const flowRight = (...functions) => input => functions.reduceRight(
    (input, fn) => fn(input),
    input
  )


const createRequest = (config) => {
    const { baseURL, apiKey, method, url } = config
    return getRequestInstance({
      baseURL,
      headers: {
        'Content-Type': 'application/json',
        'X-MBX-APIKEY': apiKey,
        //'User-Agent': `${constants.appName}/${constants.appVersion}`
      }
    }).request({
      method,
      url
    })
  }  


const Market = superclass => class extends superclass {
 
    tickerPrice (symbol = '', symbols = []) {
      symbols = symbols.map(symbol => symbol.toUpperCase())
  
      return this.publicRequest(
        'GET',
        '/api/v3/ticker/price', { symbol: symbol.toUpperCase(), symbols: symbols }
      )
    }
  
    
  }
  

class APIBase {
    constructor (options) {
      const { apiKey, apiSecret, baseURL, logger } = options
  
      this.apiKey = apiKey
      this.apiSecret = apiSecret
      this.baseURL = baseURL
      this.logger = logger 
    }
  
    publicRequest (method, path, params = {}) {
      params = removeEmptyValue(params)
      params = buildQueryString(params)
      if (params !== '') {
        path = `${path}?${params}`
      }
      return createRequest({
        method: method,
        baseURL: this.baseURL,
        url: path,
        apiKey: this.apiKey
      })
    }
  
    
  }



class Spot extends flowRight(Market)(APIBase) {
    constructor (apiKey = '', apiSecret = '', options = {}) {
      options.baseURL = options.baseURL || 'https://api.binance.com'
      super({
        apiKey,
        apiSecret,
        ...options
      })
    }
  }



const client = new Spot()

const currency = ['RUB', 'USDT'];
const needPairsBinance = ['BTC','ETH','XRP','BNB','LTC','MATIC','DOGE','WAVES','SOL','XLM','TRX','ATOM','DASH'];

const pairs = async () => {

let tickers = [];
let currencyPair = [];
let totalPair = {};
let massivUSDT = [];
let massivRUB = [];


    for (let i = 0; i < needPairsBinance.length; i++)
    {
        if(needPairsBinance[i] == 'XLM' || needPairsBinance[i] == 'TRX' || needPairsBinance[i] == 'ATOM' || needPairsBinance[i] == 'DASH')
        {
            currencyPair.push(needPairsBinance[i]+currency[1]);
        }
          
        else
        {
            currencyPair.push(needPairsBinance[i]+currency[0]);
            currencyPair.push(needPairsBinance[i]+currency[1]);

        }
       

    }
    currencyPair.push('USDTRUB');
   // console.log(currencyPair)

    await client.tickerPrice('', currencyPair).then(
        (response) => {
            tickers = response.data.map(eachItem => ({
                      symbol: eachItem.symbol,
                      price: eachItem.price
                      }))
          // console.log(tickers);

           for(let i =0; i< tickers.length; i++)
           {
            if(tickers[i].symbol.includes("USDTRUB") == false) 
            {

             if(tickers[i].symbol.includes("USDT") == true) 
             {
               
            
               massivUSDT[tickers[i].symbol.slice(0,tickers[i].symbol.search("USDT"))] = Number(tickers[i].price);
         
         
             }
             else
             {
                massivRUB[tickers[i].symbol.slice(0,tickers[i].symbol.search("RUB"))] = Number(tickers[i].price);
            
             }
            }
            else
            {
                massivUSDT['RUB'] = Number(tickers[i].price);
            }
           }

           massivRUB['XLM'] = Number(massivUSDT['XLM'])*Number(massivUSDT['RUB']);
           massivRUB['TRX'] = Number(massivUSDT['TRX'])*Number(massivUSDT['RUB']);
           massivRUB['ATOM'] = Number(massivUSDT['ATOM'])*Number(massivUSDT['RUB']);
           massivRUB['DASH'] = Number(massivUSDT['DASH'])*Number(massivUSDT['RUB']);

          
          totalPair.BTC = {"BTC" : massivUSDT.BTC/massivUSDT.BTC, "ETH" : massivUSDT.BTC/massivUSDT.ETH, 
          "RUB" : massivRUB.BTC, "XRP" : massivUSDT.BTC/massivUSDT.XRP, "BNB" : massivUSDT.BTC/massivUSDT.BNB, 
          "LTC" : massivUSDT.BTC/massivUSDT.LTC, "MATIC" : massivUSDT.BTC/massivUSDT.MATIC,
          "XLM" : massivUSDT.BTC/massivUSDT.XLM, "TRX" : massivUSDT.BTC/massivUSDT.TRX, 
          "ATOM" : massivUSDT.BTC/massivUSDT.ATOM, "DASH" : massivUSDT.BTC/massivUSDT.DASH,
          "DOGE" : massivUSDT.BTC/massivUSDT.DOGE, "WAVES" : massivUSDT.BTC/massivUSDT.WAVES, 
          "SOL" : massivUSDT.BTC/massivUSDT.SOL,  "USDT" : massivUSDT.BTC};

          totalPair.ETH = {"BTC" : massivUSDT.ETH/massivUSDT.BTC, "ETH" : massivUSDT.ETH/massivUSDT.ETH, 
          "RUB" : massivRUB.ETH, "XRP" : massivUSDT.ETH/massivUSDT.XRP, "BNB" : massivUSDT.ETH/massivUSDT.BNB, 
          "LTC" : massivUSDT.ETH/massivUSDT.LTC, "MATIC" : massivUSDT.ETH/massivUSDT.MATIC,
          "XLM" : massivUSDT.ETH/massivUSDT.XLM, "TRX" : massivUSDT.ETH/massivUSDT.TRX, 
          "ATOM" : massivUSDT.ETH/massivUSDT.ATOM, "DASH" : massivUSDT.ETH/massivUSDT.DASH,
          "DOGE" : massivUSDT.ETH/massivUSDT.DOGE, "WAVES" : massivUSDT.ETH/massivUSDT.WAVES, 
          "SOL" : massivUSDT.ETH/massivUSDT.SOL,  "USDT" : massivUSDT.ETH};

          totalPair.RUB = {"BTC" : 1/massivRUB.BTC, "ETH" : 1/massivRUB.ETH, "RUB" : 1, 
          "XRP" : 1/massivUSDT.XRP, "BNB" : 1/massivUSDT.BNB, 
          "LTC" : 1/massivUSDT.LTC, "MATIC" : 1/massivUSDT.MATIC,
          "XLM" : 1/massivUSDT.XLM, "TRX" : 1/massivUSDT.TRX, 
          "ATOM" : 1/massivUSDT.ATOM, "DASH" : 1/massivUSDT.DASH,
          "DOGE" : 1/massivUSDT.DOGE, "WAVES" : 1/massivUSDT.WAVES, 
          "SOL" : 1/massivUSDT.SOL,  "USDT" : 1/massivUSDT.RUB};

          totalPair.XRP = {"BTC" : massivUSDT.XRP/massivUSDT.BTC, "ETH" :  massivUSDT.XRP/massivUSDT.ETH, "RUB" : massivRUB.XRP, 
          "XRP" : massivUSDT.XRP/massivUSDT.XRP, "BNB" : massivUSDT.XRP/massivUSDT.BNB, 
          "LTC" : massivUSDT.XRP/massivUSDT.LTC, "MATIC" : massivUSDT.XRP/massivUSDT.MATIC,
          "XLM" : massivUSDT.XRP/massivUSDT.XLM, "TRX" : massivUSDT.XRP/massivUSDT.TRX, 
          "ATOM" : massivUSDT.XRP/massivUSDT.ATOM, "DASH" : massivUSDT.XRP/massivUSDT.DASH,
          "DOGE" : massivUSDT.XRP/massivUSDT.DOGE, "WAVES" : massivUSDT.XRP/massivUSDT.WAVES, 
          "SOL" : massivUSDT.XRP/massivUSDT.SOL,  "USDT" : massivUSDT.XRP};

          totalPair.BNB = {"BTC" : massivUSDT.BNB/massivUSDT.BTC, "ETH" :  massivUSDT.BNB/massivUSDT.ETH, "RUB" : massivRUB.BNB, 
          "XRP" : massivUSDT.BNB/massivUSDT.XRP, "BNB" : massivUSDT.BNB/massivUSDT.BNB, 
          "LTC" : massivUSDT.BNB/massivUSDT.LTC, "MATIC" : massivUSDT.BNB/massivUSDT.MATIC,
          "XLM" : massivUSDT.BNB/massivUSDT.XLM, "TRX" : massivUSDT.BNB/massivUSDT.TRX, 
          "ATOM" : massivUSDT.BNB/massivUSDT.ATOM, "DASH" : massivUSDT.BNB/massivUSDT.DASH,
          "DOGE" : massivUSDT.BNB/massivUSDT.DOGE, "WAVES" : massivUSDT.BNB/massivUSDT.WAVES, 
          "SOL" : massivUSDT.BNB/massivUSDT.SOL,  "USDT" : massivUSDT.BNB};

          totalPair.LTC = {"BTC" : massivUSDT.LTC/massivUSDT.BTC, "ETH" :  massivUSDT.LTC/massivUSDT.ETH, "RUB" : massivRUB.LTC, 
          "XRP" : massivUSDT.LTC/massivUSDT.XRP, "BNB" : massivUSDT.LTC/massivUSDT.BNB, 
          "LTC" : massivUSDT.LTC/massivUSDT.LTC, "MATIC" : massivUSDT.LTC/massivUSDT.MATIC,
          "XLM" : massivUSDT.LTC/massivUSDT.XLM, "TRX" : massivUSDT.LTC/massivUSDT.TRX, 
          "ATOM" : massivUSDT.LTC/massivUSDT.ATOM, "DASH" : massivUSDT.LTC/massivUSDT.DASH,
          "DOGE" : massivUSDT.LTC/massivUSDT.DOGE, "WAVES" : massivUSDT.LTC/massivUSDT.WAVES, 
          "SOL" : massivUSDT.LTC/massivUSDT.SOL,  "USDT" : massivUSDT.LTC};

          totalPair.MATIC = {"BTC" : massivUSDT.MATIC/massivUSDT.BTC, "ETH" :  massivUSDT.MATIC/massivUSDT.ETH, "RUB" : massivRUB.MATIC, 
          "XRP" : massivUSDT.MATIC/massivUSDT.XRP, "BNB" : massivUSDT.MATIC/massivUSDT.BNB, 
          "LTC" : massivUSDT.MATIC/massivUSDT.LTC, "MATIC" : massivUSDT.MATIC/massivUSDT.MATIC,
          "XLM" : massivUSDT.MATIC/massivUSDT.XLM, "TRX" : massivUSDT.MATIC/massivUSDT.TRX, 
          "ATOM" : massivUSDT.MATIC/massivUSDT.ATOM, "DASH" : massivUSDT.MATIC/massivUSDT.DASH,
          "DOGE" : massivUSDT.MATIC/massivUSDT.DOGE, "WAVES" : massivUSDT.MATIC/massivUSDT.WAVES, 
          "SOL" : massivUSDT.MATIC/massivUSDT.SOL,  "USDT" : massivUSDT.MATIC};

          totalPair.XLM = {"BTC" : massivUSDT.XLM/massivUSDT.BTC, "ETH" :  massivUSDT.XLM/massivUSDT.ETH, "RUB" : massivRUB.XLM, 
          "XRP" : massivUSDT.XLM/massivUSDT.XRP, "BNB" : massivUSDT.XLM/massivUSDT.BNB, 
          "LTC" : massivUSDT.XLM/massivUSDT.LTC, "MATIC" : massivUSDT.XLM/massivUSDT.MATIC,
          "XLM" : massivUSDT.XLM/massivUSDT.XLM, "TRX" : massivUSDT.XLM/massivUSDT.TRX, 
          "ATOM" : massivUSDT.XLM/massivUSDT.ATOM, "DASH" : massivUSDT.XLM/massivUSDT.DASH,
          "DOGE" : massivUSDT.XLM/massivUSDT.DOGE, "WAVES" : massivUSDT.XLM/massivUSDT.WAVES, 
          "SOL" : massivUSDT.XLM/massivUSDT.SOL,  "USDT" : massivUSDT.XLM};

          totalPair.TRX = {"BTC" : massivUSDT.TRX/massivUSDT.BTC, "ETH" :  massivUSDT.TRX/massivUSDT.ETH, "RUB" : massivRUB.TRX, 
          "XRP" : massivUSDT.TRX/massivUSDT.XRP, "BNB" : massivUSDT.TRX/massivUSDT.BNB, 
          "LTC" : massivUSDT.TRX/massivUSDT.LTC, "MATIC" : massivUSDT.TRX/massivUSDT.MATIC,
          "XLM" : massivUSDT.TRX/massivUSDT.XLM, "TRX" : massivUSDT.TRX/massivUSDT.TRX, 
          "ATOM" : massivUSDT.TRX/massivUSDT.ATOM, "DASH" : massivUSDT.TRX/massivUSDT.DASH,
          "DOGE" : massivUSDT.TRX/massivUSDT.DOGE, "WAVES" : massivUSDT.TRX/massivUSDT.WAVES, 
          "SOL" : massivUSDT.TRX/massivUSDT.SOL,  "USDT" : massivUSDT.TRX};
         
          totalPair.ATOM = {"BTC" : massivUSDT.ATOM/massivUSDT.BTC, "ETH" :  massivUSDT.ATOM/massivUSDT.ETH, "RUB" : massivRUB.ATOM, 
          "XRP" : massivUSDT.ATOM/massivUSDT.XRP, "BNB" : massivUSDT.ATOM/massivUSDT.BNB, 
          "LTC" : massivUSDT.ATOM/massivUSDT.LTC, "MATIC" : massivUSDT.ATOM/massivUSDT.MATIC,
          "XLM" : massivUSDT.ATOM/massivUSDT.XLM, "TRX" : massivUSDT.ATOM/massivUSDT.TRX, 
          "ATOM" : massivUSDT.ATOM/massivUSDT.ATOM, "DASH" : massivUSDT.ATOM/massivUSDT.DASH,
          "DOGE" : massivUSDT.ATOM/massivUSDT.DOGE, "WAVES" : massivUSDT.ATOM/massivUSDT.WAVES, 
          "SOL" : massivUSDT.ATOM/massivUSDT.SOL,  "USDT" : massivUSDT.ATOM};

          totalPair.DASH = {"BTC" : massivUSDT.DASH/massivUSDT.BTC, "ETH" :  massivUSDT.DASH/massivUSDT.ETH, "RUB" : massivRUB.DASH, 
          "XRP" : massivUSDT.DASH/massivUSDT.XRP, "BNB" : massivUSDT.DASH/massivUSDT.BNB, 
          "LTC" : massivUSDT.DASH/massivUSDT.LTC, "MATIC" : massivUSDT.DASH/massivUSDT.MATIC,
          "XLM" : massivUSDT.DASH/massivUSDT.XLM, "TRX" : massivUSDT.DASH/massivUSDT.TRX, 
          "ATOM" : massivUSDT.DASH/massivUSDT.ATOM, "DASH" : massivUSDT.DASH/massivUSDT.DASH,
          "DOGE" : massivUSDT.DASH/massivUSDT.DOGE, "WAVES" : massivUSDT.DASH/massivUSDT.WAVES, 
          "SOL" : massivUSDT.DASH/massivUSDT.SOL,  "USDT" : massivUSDT.DASH};

          totalPair.DOGE = {"BTC" : massivUSDT.DOGE/massivUSDT.BTC, "ETH" :  massivUSDT.DOGE/massivUSDT.ETH, "RUB" : massivRUB.DOGE, 
          "XRP" : massivUSDT.DOGE/massivUSDT.XRP, "BNB" : massivUSDT.DOGE/massivUSDT.BNB, 
          "LTC" : massivUSDT.DOGE/massivUSDT.LTC, "MATIC" : massivUSDT.DOGE/massivUSDT.MATIC,
          "XLM" : massivUSDT.DOGE/massivUSDT.XLM, "TRX" : massivUSDT.DOGE/massivUSDT.TRX, 
          "ATOM" : massivUSDT.DOGE/massivUSDT.ATOM, "DASH" : massivUSDT.DOGE/massivUSDT.DASH,
          "DOGE" : massivUSDT.DOGE/massivUSDT.DOGE, "WAVES" : massivUSDT.DOGE/massivUSDT.WAVES, 
          "SOL" : massivUSDT.DOGE/massivUSDT.SOL,  "USDT" : massivUSDT.DOGE};

          totalPair.WAVES = {"BTC" : massivUSDT.WAVES/massivUSDT.BTC, "ETH" :  massivUSDT.WAVES/massivUSDT.ETH, "RUB" : massivRUB.WAVES, 
          "XRP" : massivUSDT.WAVES/massivUSDT.XRP, "BNB" : massivUSDT.WAVES/massivUSDT.BNB, 
          "LTC" : massivUSDT.WAVES/massivUSDT.LTC, "MATIC" : massivUSDT.WAVES/massivUSDT.MATIC,
          "XLM" : massivUSDT.WAVES/massivUSDT.XLM, "TRX" : massivUSDT.WAVES/massivUSDT.TRX, 
          "ATOM" : massivUSDT.WAVES/massivUSDT.ATOM, "DASH" : massivUSDT.WAVES/massivUSDT.DASH,
          "DOGE" : massivUSDT.WAVES/massivUSDT.DOGE, "WAVES" : massivUSDT.WAVES/massivUSDT.WAVES, 
          "SOL" : massivUSDT.WAVES/massivUSDT.SOL,  "USDT" : massivUSDT.WAVES};

          totalPair.SOL = {"BTC" : massivUSDT.SOL/massivUSDT.BTC, "ETH" :  massivUSDT.SOL/massivUSDT.ETH, "RUB" : massivRUB.SOL, 
          "XRP" : massivUSDT.SOL/massivUSDT.XRP, "BNB" : massivUSDT.SOL/massivUSDT.BNB, 
          "LTC" : massivUSDT.SOL/massivUSDT.LTC, "MATIC" : massivUSDT.SOL/massivUSDT.MATIC,
          "XLM" : massivUSDT.SOL/massivUSDT.XLM, "TRX" : massivUSDT.SOL/massivUSDT.TRX, 
          "ATOM" : massivUSDT.SOL/massivUSDT.ATOM, "DASH" : massivUSDT.SOL/massivUSDT.DASH,
          "DOGE" : massivUSDT.SOL/massivUSDT.DOGE, "WAVES" : massivUSDT.SOL/massivUSDT.WAVES, 
          "SOL" : massivUSDT.SOL/massivUSDT.SOL,  "USDT" : massivUSDT.SOL};

          totalPair.USDT = {"BTC" : 1/massivUSDT.BTC, "ETH" :  1/massivUSDT.ETH, "RUB" : massivUSDT.RUB, 
          "XRP" : 1/massivUSDT.XRP, "BNB" : 1/massivUSDT.BNB, 
          "LTC" : 1/massivUSDT.LTC, "MATIC" : 1/massivUSDT.MATIC,
          "XLM" : 1/massivUSDT.XLM, "TRX" : 1/massivUSDT.TRX, 
          "ATOM" : 1/massivUSDT.ATOM, "DASH" : 1/massivUSDT.DASH,
          "DOGE" : 1/massivUSDT.DOGE, "WAVES" : 1/massivUSDT.WAVES, 
          "SOL" : 1/massivUSDT.SOL,  "USDT" : 1};

          },
          
          (error) => {
            console.log(error);
            
        
          } 
          
          
          );

 return totalPair;
   
}

module.exports = pairs



